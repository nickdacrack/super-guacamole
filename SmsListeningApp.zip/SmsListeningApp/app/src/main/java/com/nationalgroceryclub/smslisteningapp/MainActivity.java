package com.nationalgroceryclub.smslisteningapp;

import android.app.ProgressDialog;
import android.content.IntentFilter;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static String smsSender = "";

    TextView tv;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("");
        progressDialog.show();

        String str = getIntent().getStringExtra("msg");

        tv = (TextView)findViewById(R.id.txtTextMessage);
        tv.setText(""+str);

        new CountDownTimer(40000, 1000) {

            public void onTick(long millisUntilFinished) {
                tv.setText("seconds remaining: " + millisUntilFinished / 1000);
                progressDialog.setMessage("seconds remaining: " + millisUntilFinished / 1000);
                if (smsSender.equals("+263784426416")){
                    this.onFinish();
                    cancel();
                }
            }

            public void onFinish() {
                tv.setText("done!");
                progressDialog.hide();
                cancel();
            }
        }.start();
        //this.registerReceiver(new SmsListener(), new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
        //this.unregisterReceiver(new SmsListener());
    }
}
